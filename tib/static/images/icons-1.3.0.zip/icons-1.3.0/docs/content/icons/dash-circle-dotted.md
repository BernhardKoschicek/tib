---
title: Dash circle dotted
categories:
  - Alerts, warnings, and signs
tags:
  - minus
---
