---
title: Arrow right-short
categories:
  - Arrows
tags:
  - arrow
---
